# Telegram File Bot

## Render Environment Variables
| Key | Required | Value |
|---|---|---|
| API_ID | ✅ | my.telegram.org থেকে |
| API_HASH | ✅ | my.telegram.org থেকে |
| BOT_TOKEN | ✅ | @BotFather থেকে |
| ALLOWED_USERS | ⭕ | আপনার Telegram numeric ID (কমা দিয়ে একাধিক) |
| MAX_FILE_MB | ⭕ | ডিফল্ট 1500 |
| MAX_JOBS | ⭕ | ডিফল্ট 2 |

PORT Render নিজেই দেয়।

## Deploy
1. GitHub এ সব ফাইল আপলোড করুন
2. Render → New → Web Service → repo বেছে নিন
3. Runtime: **Docker** (ffmpeg দরকার)
4. উপরের Environment Variables বসান → Deploy
5. UptimeRobot দিয়ে `https://<app>.onrender.com/health` প্রতি ৫ মিনিটে ping করুন (free plan এ ঘুমিয়ে না পড়ার জন্য)

## মোডসমূহ
- 🔄 doc2org_mode — ডকুমেন্ট → আসল রূপ
- 💳 rename_mode — নাম/ফরমেট পরিবর্তন
- 🌠 C_Thumb_mode — ভিডিওর থাম্বনেইল পরিবর্তন (Auto 3টি / Manual)
- ⏩ Fast_GIF_mode — র‍্যান্ডম GIF ক্লিপ (`/gifdefault` দিয়ে Default দেখা/বাদ দেওয়া)

কমান্ড: `/start` `/cancel` `/gifdefault`

নোট: মোড ও GIF Default `settings.json` এ সেভ হয়। Render Free এ নতুন deploy হলে এটি মুছে যেতে পারে।
