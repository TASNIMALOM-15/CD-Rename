# Telegram File Bot

## Render Environment Variables
| Key | Required | Value |
|---|---|---|
| API_ID | ✅ | my.telegram.org থেকে |
| API_HASH | ✅ | my.telegram.org থেকে |
| BOT_TOKEN | ✅ | @BotFather থেকে |
| ALLOWED_USERS | ⭕ | আপনার Telegram numeric ID (কমা দিয়ে একাধিক) |
| MAX_FILE_MB | ⭕ | ডিফল্ট 1500 |
| MAX_JOBS | ⭕ | ডিফল্ট 2 |

PORT Render নিজেই দেয়।

## Deploy
1. GitHub এ সব ফাইল আপলোড করুন
2. Render → New → Web Service → repo বেছে নিন
3. Runtime: **Docker** (ffmpeg দরকার)
4. উপরের Environment Variables বসান → Deploy
5. UptimeRobot দিয়ে `https://<app>.onrender.com/health` প্রতি ৫ মিনিটে ping করুন (free plan এ ঘুমিয়ে না পড়ার জন্য)
